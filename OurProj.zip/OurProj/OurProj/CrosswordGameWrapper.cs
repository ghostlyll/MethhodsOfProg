﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.IO;
using System.Diagnostics;

namespace OurProj
{
    public class CrosswordGameWrapper : Game
    {
        private CrosswordGrid _grid;
        private List<CrosswordQuestion> _questions;
        private CrosswordGame _game;
        private Victorine.Student _currentStudent;
        private CrosswordResult _currentResult;
        private Stopwatch _timer;

        public CrosswordGrid Grid => _grid;
        public List<CrosswordQuestion> Questions => _questions;
        public CrosswordGame CurrentGame => _game;
        public Victorine.Student CurrentStudent => _currentStudent;
        public CrosswordResult CurrentResult => _currentResult;
        public TimeSpan ElapsedTime => _timer?.Elapsed ?? TimeSpan.Zero;

        // Вспомогательный класс для результатов слова
        public class CrosswordWordResultWrapper
        {
            public int Number { get; set; }
            public string Text { get; set; }
            public string Solution { get; set; }
            public bool IsSolved { get; set; }
        }

        public bool IsPossibleToConstruct()
        {
            return _grid != null && _questions != null && _questions.Count > 0;
        }

        public void LoadFromXML(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                    throw new FileNotFoundException($"XML файл не найден: {filePath}");

                var xmlDoc = XDocument.Load(filePath);

                // Проверяем корневой элемент
                if (xmlDoc.Root == null)
                    throw new Exception("XML файл пустой или невалидный.");

                if (xmlDoc.Root.Name != "crossword")
                    throw new Exception($"Ожидался элемент 'crossword', но найден '{xmlDoc.Root.Name}'");

                // Читаем информацию о кроссворде
                var infoElement = xmlDoc.Root.Element("info");
                if (infoElement == null)
                    throw new Exception("Не найден элемент 'info' в XML");

                int size = 15; // значение по умолчанию
                var sizeElement = infoElement.Element("size");
                if (sizeElement != null && int.TryParse(sizeElement.Value, out int parsedSize))
                {
                    size = parsedSize;
                }

                _grid = new CrosswordGrid(size);
                _questions = new List<CrosswordQuestion>();

                // Читаем ячейки сетки
                var gridElement = xmlDoc.Root.Element("grid");
                if (gridElement == null)
                    throw new Exception("Не найден элемент 'grid' в XML");

                var rows = gridElement.Elements("row").ToList();
                if (rows.Count != size)
                    throw new Exception($"Ожидалось {size} строк, но найдено {rows.Count}");

                for (int rowIndex = 0; rowIndex < rows.Count; rowIndex++)
                {
                    var row = rows[rowIndex];
                    var cells = row.Elements("cell").ToList();

                    if (cells.Count != size)
                        throw new Exception($"В строке {rowIndex} ожидалось {size} ячеек, но найдено {cells.Count}");

                    for (int colIndex = 0; colIndex < cells.Count; colIndex++)
                    {
                        var cellValue = cells[colIndex].Value;
                        _grid.Grid[colIndex, rowIndex] = string.IsNullOrEmpty(cellValue) || cellValue == " " ? (char?)null : cellValue[0];
                    }
                }

                // Читаем размещения слов (опционально)
                var placementsElement = xmlDoc.Root.Element("placements");
                if (placementsElement != null)
                {
                    foreach (var placement in placementsElement.Elements("placement"))
                    {
                        var word = placement.Element("word")?.Value;
                        var xElement = placement.Element("x")?.Value;
                        var yElement = placement.Element("y")?.Value;
                        var directionElement = placement.Element("direction")?.Value;

                        if (word != null && xElement != null && yElement != null && directionElement != null)
                        {
                            if (int.TryParse(xElement, out int x) && int.TryParse(yElement, out int y))
                            {
                                var direction = (Direction)Enum.Parse(typeof(Direction), directionElement);
                                _grid.Placements.Add(new WordPlacement(word, x, y, direction));
                            }
                        }
                    }
                }

                // Читаем вопросы
                var questionsElement = xmlDoc.Root.Element("questions");
                if (questionsElement == null)
                    throw new Exception("Не найден элемент 'questions' в XML");

                int questionNumber = 1;
                foreach (var question in questionsElement.Elements("question"))
                {
                    var textElement = question.Element("text");
                    var answerElement = question.Element("answer");

                    if (textElement != null && answerElement != null)
                    {
                        _questions.Add(new CrosswordQuestion
                        {
                            Number = questionNumber,
                            Question = textElement.Value,
                            Answer = answerElement.Value,
                            Solved = false
                        });
                        questionNumber++;
                    }
                }

                if (_questions.Count == 0)
                    throw new Exception("Не найдено ни одного вопроса в XML");

                // Создаем игру
                _game = new CrosswordGame(_grid, _questions);
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка загрузки кроссворда из XML: {ex.Message}", ex);
            }
        }

        // Метод для создания кроссворда из TXT (для учителя)
        public void CreateFromTxt(string filePath)
        {
            var taskReader = new TaskReader();
            taskReader.ReadFromFile(filePath);

            if (taskReader.Tasks == null || taskReader.Tasks.Count == 0)
                throw new Exception("Файл не содержит корректных заданий.");

            // Создаем вопросы в правильном порядке
            _questions = new List<CrosswordQuestion>();
            var answers = new List<string>();

            for (int i = 0; i < taskReader.Tasks.Count; i++)
            {
                var task = taskReader.Tasks[i];

                if (!IsValidCrosswordAnswer(task.Answer))
                {
                    throw new Exception(
                        $"Ответ '{task.Answer}' в вопросе №{task.Number} содержит недопустимые символы.\n" +
                        "Для кроссворда ответ должен состоять только из букв.");
                }

                _questions.Add(new CrosswordQuestion
                {
                    Number = task.Number, // Сохраняем оригинальный номер из файла
                    Question = task.Question,
                    Answer = task.Answer.ToUpper(),
                    Solved = false
                });

                answers.Add(task.Answer.ToUpper());
            }

            // Сортируем вопросы по номеру
            _questions = _questions.OrderBy(q => q.Number).ToList();

            // Генерируем кроссворд с сохранением связи между словами и вопросами
            GenerateCrosswordWithMapping(answers.ToArray());
        }

        private void GenerateCrosswordWithMapping(string[] answers)
        {
            var generator = new CrosswordGenerator();
            _grid = generator.Generate(answers, 15);

            // Создаем словарь для связи номеров вопросов с размещениями
            var placementToQuestionMap = new Dictionary<int, WordPlacement>();

            // Переупорядочиваем размещения в соответствии с номерами вопросов
            var sortedPlacements = new List<WordPlacement>();

            for (int i = 0; i < _questions.Count; i++)
            {
                if (i < _grid.Placements.Count)
                {
                    _grid.Placements[i].Word = _questions[i].Answer;
                    _questions[i].Number = i + 1; // Гарантируем последовательную нумерацию
                }
            }

            _game = new CrosswordGame(_grid, _questions);
        }

        // Метод для ученика - простая загрузка
        public void LoadForStudent(string filePath)
        {
            try
            {
                var xmlDoc = XDocument.Load(filePath);

                if (xmlDoc.Root?.Name != "crossword")
                    throw new Exception("Неверный формат файла. Ожидался кроссворд.");

                // Получаем ответы из вопросов
                var questionsElement = xmlDoc.Root.Element("questions");
                if (questionsElement == null)
                    throw new Exception("Не найден список вопросов");

                var answers = questionsElement.Elements("question")
                    .Select(q => q.Element("answer")?.Value.ToUpper() ?? "")
                    .Where(a => !string.IsNullOrEmpty(a))
                    .ToArray();

                if (answers.Length == 0)
                    throw new Exception("Нет вопросов в файле");

                // Получаем размер
                int size = 15;
                var sizeElement = xmlDoc.Root.Element("info")?.Element("size");
                if (sizeElement != null)
                    int.TryParse(sizeElement.Value, out size);

                // Генерируем кроссворд
                var generator = new CrosswordGenerator();
                _grid = generator.Generate(answers, size);

                // Создаем вопросы
                _questions = new List<CrosswordQuestion>();
                int i = 1;
                foreach (var question in questionsElement.Elements("question"))
                {
                    var text = question.Element("text")?.Value ?? $"Вопрос {i}";
                    var answer = question.Element("answer")?.Value.ToUpper() ?? "";

                    if (!string.IsNullOrEmpty(answer))
                    {
                        _questions.Add(new CrosswordQuestion
                        {
                            Number = i,
                            Question = text,
                            Answer = answer,
                            Solved = false
                        });
                        i++;
                    }
                }

                _game = new CrosswordGame(_grid, _questions);
            }
            catch (Exception ex)
            {
                throw new Exception($"Не удалось загрузить кроссворд: {ex.Message}", ex);
            }
        }

        private bool IsValidCrosswordAnswer(string answer)
        {
            // Проверяем, что ответ состоит только из букв
            return !string.IsNullOrEmpty(answer) &&
                   answer.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }

        public void SetStudent(string firstName, string lastName, string group)
        {
            _currentStudent = new Victorine.Student
            {
                FirstName = firstName,
                LastName = lastName,
                Group = group
            };
        }

        //public void StartNewGame()
        //{
        //    _currentResult = new CrosswordResult
        //    {
        //        StudentName = $"{_currentStudent.FirstName} {_currentStudent.LastName}",
        //        StudentGroup = _currentStudent.Group,
        //        TotalWords = _questions.Count,
        //        SolvedWords = 0,
        //        CompletionTime = DateTime.Now,
        //        TimeSpent = TimeSpan.Zero,
        //        WordResults = new List<CrosswordWordResult>()
        //    };

        //    _timer = Stopwatch.StartNew();
        //}
        public void StartNewGame()
        {
            _currentResult = new CrosswordResult
            {
                StudentName = $"{_currentStudent.FirstName} {_currentStudent.LastName}",
                StudentGroup = _currentStudent.Group,
                TotalWords = _questions.Count,
                SolvedWords = 0,
                CompletionTime = DateTime.Now,
                TimeSpent = TimeSpan.Zero, // Оставляем нулевое время
                WordResults = new List<CrosswordWordResult>()
            };

            // Убрали создание таймера
        }

        public void SaveAsXML()
        {
            if (_currentResult == null || _currentStudent == null)
                throw new InvalidOperationException("Нет результатов для сохранения");

            // Убрали остановку таймера
            _currentResult.TimeSpent = TimeSpan.Zero; // Всегда нулевое время

            string fileName = $"{_currentStudent.LastName}_{_currentStudent.FirstName}_crossword_results.xml";
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, fileName);

            var xmlDoc = new XDocument(
                new XElement("crosswordResults",
                    new XElement("student",
                        new XElement("firstName", _currentStudent.FirstName),
                        new XElement("lastName", _currentStudent.LastName),
                        new XElement("group", _currentStudent.Group)
                    ),
                    new XElement("gameInfo",
                        new XElement("completionTime", _currentResult.CompletionTime.ToString("o")),
                        new XElement("timeSpent", _currentResult.TimeSpent.ToString()),
                        new XElement("totalWords", _currentResult.TotalWords),
                        new XElement("solvedWords", _currentResult.SolvedWords),
                        new XElement("percentage", _currentResult.Percentage)
                    )
                    
                )
            );

            xmlDoc.Save(filePath);
        }

        
        public void PlayGame()
        {
            StartNewGame();
        }

        public bool CheckAnswer(string answer, int questionNumber = -1)
        {
            CrosswordQuestion question;

            if (questionNumber > 0)
            {
                question = _questions.FirstOrDefault(q => q.Number == questionNumber);
            }
            else
            {
                // Ищем первый нерешенный вопрос
                question = _questions.FirstOrDefault(q => !q.Solved);
            }

            if (question == null)
                return false;

            bool isCorrect = _game.TrySolve(question.Number - 1, answer);



            if (isCorrect)
            {
                question.Solved = true;

                // Обновляем результаты
                if (_currentResult != null)
                {
                    _currentResult.SolvedWords++;
                    _currentResult.Percentage = (double)_currentResult.SolvedWords / _currentResult.TotalWords * 100;

                    _currentResult.WordResults.Add(new CrosswordWordResult
                    {
                        QuestionNumber = question.Number,
                        Question = question.Question,
                        Answer = question.Answer,
                        Solved = true
                    });
                }

                return true;
            }

            return false;
        }

        //public void SaveAsXML()
        //{
        //    if (_currentResult == null || _currentStudent == null)
        //        throw new InvalidOperationException("Нет результатов для сохранения");

        //    // Останавливаем таймер
        //    _timer?.Stop();
        //    _currentResult.TimeSpent = _timer?.Elapsed ?? TimeSpan.Zero;

        //    string fileName = $"{_currentStudent.LastName}_{_currentStudent.FirstName}_crossword_results.xml";
        //    string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        //    string filePath = Path.Combine(desktopPath, fileName);

        //    var xmlDoc = new XDocument(
        //        new XElement("crosswordResults",
        //            new XElement("student",
        //                new XElement("firstName", _currentStudent.FirstName),
        //                new XElement("lastName", _currentStudent.LastName),
        //                new XElement("group", _currentStudent.Group)
        //            ),
        //            new XElement("gameInfo",
        //                new XElement("completionTime", _currentResult.CompletionTime.ToString("o")),
        //                new XElement("timeSpent", _currentResult.TimeSpent.ToString()),
        //                new XElement("totalWords", _currentResult.TotalWords),
        //                new XElement("solvedWords", _currentResult.SolvedWords),
        //                new XElement("percentage", _currentResult.Percentage)
        //            ),
        //            new XElement("solvedWords",
        //                _currentResult.WordResults.Select(w =>
        //                    new XElement("word",
        //                        new XAttribute("number", w.QuestionNumber),
        //                        new XElement("question", w.Question),
        //                        new XElement("answer", w.Answer)
        //                    )
        //                )
        //            ),
        //            new XElement("finalGrid",
        //                new XAttribute("size", _grid.Size),
        //                Enumerable.Range(0, _grid.Size).Select(y =>
        //                    new XElement("row",
        //                        new XAttribute("y", y),
        //                        Enumerable.Range(0, _grid.Size).Select(x =>
        //                            new XElement("cell",
        //                                new XAttribute("x", x),
        //                                _game.GetCell(x, y)?.ToString() ?? " "
        //                            )
        //                        )
        //                    )
        //                )
        //            )
        //        )
        //    );

        //    xmlDoc.Save(filePath);
        //}

        public void SaveAnswers()
        {
            if (_currentResult == null || _currentStudent == null)
                throw new InvalidOperationException("Нет данных для сохранения");

            
            // Сохраняем результаты в текстовый файл
            string fileName = $"{_currentStudent.LastName}_{_currentStudent.FirstName}_кроссворд_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, fileName);

            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine($"КРОССВОРД - РЕЗУЛЬТАТЫ");
                writer.WriteLine(new string('=', 50));
                writer.WriteLine($"Студент: {_currentStudent.FirstName} {_currentStudent.LastName}");
                writer.WriteLine($"Группа: {_currentStudent.Group}");
                writer.WriteLine($"Дата прохождения: {_currentResult.CompletionTime:dd.MM.yyyy HH:mm:ss}");
                writer.WriteLine($"Затраченное время: {_currentResult.TimeSpent:mm\\:ss}");
                writer.WriteLine(new string('-', 50));
                writer.WriteLine($"Всего слов: {_currentResult.TotalWords}");
                writer.WriteLine($"Разгадано слов: {_currentResult.SolvedWords}");
                writer.WriteLine($"Процент разгаданных: {_currentResult.Percentage:F1}%");
                writer.WriteLine(new string('-', 50));

                if (_currentResult.WordResults.Any())
                {
                    writer.WriteLine("\nРАЗГАДАННЫЕ СЛОВА:");
                    writer.WriteLine(new string('-', 50));

                    foreach (var word in _currentResult.WordResults.OrderBy(w => w.QuestionNumber))
                    {
                        writer.WriteLine($"\nСлово {word.QuestionNumber}: {word.Question}");
                        writer.WriteLine($"Ответ: {word.Answer}");
                    }
                }

                // Сохраняем итоговую сетку
                writer.WriteLine("\n\nИТОГОВАЯ СЕТКА КРОССВОРДА:");
                writer.WriteLine(new string('-', 50));
                writer.WriteLine();

                for (int y = 0; y < _grid.Size; y++)
                {
                    for (int x = 0; x < _grid.Size; x++)
                    {
                        var cell = _game.GetCell(x, y);
                        writer.Write(cell?.ToString() ?? ".");
                    }
                    writer.WriteLine();
                }
            }
        }

        public void VerifyPlacements()
        {
            if (_questions == null || _grid == null || _grid.Placements == null)
                return;

            Console.WriteLine("Проверка соответствия вопросов и размещений:");
            for (int i = 0; i < Math.Min(_questions.Count, _grid.Placements.Count); i++)
            {
                var question = _questions[i];
                var placement = _grid.Placements[i];

                bool matches = string.Equals(question.Answer, placement.Word, StringComparison.OrdinalIgnoreCase);

                Console.WriteLine($"Вопрос {question.Number}: '{question.Answer}' - " +
                                 $"Размещение {i}: '{placement.Word}' - " +
                                 $"Совпадение: {matches}");
            }
        }

        // Метод для сохранения кроссворда в XML (для учителя)
        public void SaveCrosswordAsXML(string filePath)
        {
            if (_grid == null || _questions == null)
                throw new InvalidOperationException("Нет данных кроссворда для сохранения");

            var xmlDoc = new XDocument(
                new XElement("crossword",
                    new XElement("info",
                        new XElement("title", "Кроссворд"),
                        new XElement("creationDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")),
                        new XElement("size", _grid.Size),
                        new XElement("totalWords", _questions.Count)
                    ),
                    new XElement("grid",
                        Enumerable.Range(0, _grid.Size).Select(y =>
                            new XElement("row",
                                new XAttribute("y", y),
                                Enumerable.Range(0, _grid.Size).Select(x =>
                                    new XElement("cell",
                                        new XAttribute("x", x),
                                        _grid.Grid[x, y]?.ToString() ?? ""
                                    )
                                )
                            )
                        )
                    ),
                    new XElement("placements",
                        _grid.Placements.Select(p =>
                            new XElement("placement",
                                new XElement("word", p.Word),
                                new XElement("x", p.X),
                                new XElement("y", p.Y),
                                new XElement("direction", p.Direction.ToString())
                            )
                        )
                    ),
                    new XElement("questions",
                        _questions.Select(q =>
                            new XElement("question",
                                new XElement("number", q.Number),
                                new XElement("text", q.Question),
                                new XElement("answer", q.Answer)
                            )
                        )
                    )
                )
            );

            xmlDoc.Save(filePath);
        }

        public bool IsComplete()
        {
            return _currentResult != null && _currentResult.SolvedWords == _currentResult.TotalWords;
        }
    }
}