﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace OurProj
{
    // Direction.cs
    public enum Direction { Horizontal, Vertical }

    // WordPlacement.cs
    public class WordPlacement
    {
        public string Word { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public Direction Direction { get; set; }

        public WordPlacement() { }

        public WordPlacement(string word, int x, int y, Direction direction)
        {
            Word = word;
            X = x;
            Y = y;
            Direction = direction;
        }
    }

    // Crossword.cs
    public class CrosswordGrid
    {
        public char?[,] Grid { get; private set; }
        public List<WordPlacement> Placements { get; } = new List<WordPlacement>();
        public int Size { get; private set; }

        public CrosswordGrid() { }

        public CrosswordGrid(int size)
        {
            Size = size;
            Grid = new char?[size, size];
        }

        public bool CanPlace(string word, int x, int y, Direction dir)
        {
            for (int i = 0; i < word.Length; i++)
            {
                int cx = x + (dir == Direction.Horizontal ? i : 0);
                int cy = y + (dir == Direction.Vertical ? i : 0);
                if (cx < 0 || cy < 0 || cx >= Size || cy >= Size) return false;
                if (Grid[cx, cy] != null && Grid[cx, cy] != word[i]) return false;
            }
            return true;
        }

        public void Place(string word, int x, int y, Direction dir)
        {
            for (int i = 0; i < word.Length; i++)
            {
                int cx = x + (dir == Direction.Horizontal ? i : 0);
                int cy = y + (dir == Direction.Vertical ? i : 0);
                Grid[cx, cy] = word[i];
            }
            Placements.Add(new WordPlacement(word, x, y, dir));
        }

        public void Clear()
        {
            int size = Grid.GetLength(0);
            Grid = new char?[size, size];
            Placements.Clear();
        }
    }

    // CrosswordGenerator.cs
    public class CrosswordGenerator
    {
        private const int MAX_ATTEMPTS = 100;
        private Random _random = new Random();

        public CrosswordGrid Generate(string[] words, int size = 15)
        {
            if (words == null || words.Length == 0)
                return new CrosswordGrid(size);

            var grid = new CrosswordGrid(size);

            // Сортируем слова по длине (самые длинные сначала) и сохраняем оригинальные индексы
            var wordItems = words
                .Where(w => !string.IsNullOrEmpty(w))
                .Select((w, idx) => new { Word = w.ToUpper(), OriginalIndex = idx, Length = w.Length })
                .OrderByDescending(w => w.Length)
                .ThenBy(w => w.OriginalIndex)
                .ToList();

            if (!wordItems.Any())
                return grid;

            // Размещаем первое слово в центре
            var firstWord = wordItems[0];
            int centerX = (size - firstWord.Word.Length) / 2;
            int centerY = size / 2;

            if (grid.CanPlace(firstWord.Word, centerX, centerY, Direction.Horizontal))
            {
                grid.Place(firstWord.Word, centerX, centerY, Direction.Horizontal);
                wordItems.RemoveAt(0);
            }

            // Размещаем остальные слова
            foreach (var wordItem in wordItems)
            {
                bool placed = TryPlaceWord(grid, wordItem.Word);
                if (!placed)
                {
                    // Если не удалось разместить, просто добавляем в конец списка для повторной попытки
                    Console.WriteLine($"Не удалось разместить слово: {wordItem.Word}");
                }
            }

            return grid;
        }

        private bool TryPlaceWord(CrosswordGrid grid, string word)
        {
            // Сначала ищем пересечения с уже размещенными словами
            foreach (var placement in grid.Placements)
            {
                for (int i = 0; i < placement.Word.Length; i++)
                {
                    for (int j = 0; j < word.Length; j++)
                    {
                        if (placement.Word[i] == word[j])
                        {
                            // Пробуем разместить перпендикулярно
                            var newDirection = placement.Direction == Direction.Horizontal
                                ? Direction.Vertical
                                : Direction.Horizontal;

                            int newX = placement.X;
                            int newY = placement.Y;

                            if (placement.Direction == Direction.Horizontal)
                            {
                                newX += i;
                                newY -= j;
                            }
                            else // Vertical
                            {
                                newX -= j;
                                newY += i;
                            }

                            if (grid.CanPlace(word, newX, newY, newDirection))
                            {
                                grid.Place(word, newX, newY, newDirection);
                                return true;
                            }

                            // Пробуем другое направление
                            newDirection = newDirection == Direction.Horizontal
                                ? Direction.Vertical
                                : Direction.Horizontal;

                            if (placement.Direction == Direction.Horizontal)
                            {
                                newX = placement.X + i;
                                newY = placement.Y;
                            }
                            else // Vertical
                            {
                                newX = placement.X;
                                newY = placement.Y + i;
                            }

                            if (grid.CanPlace(word, newX, newY, newDirection))
                            {
                                grid.Place(word, newX, newY, newDirection);
                                return true;
                            }
                        }
                    }
                }
            }

            // Если не нашли пересечений, пробуем разместить рядом с существующими словами
            return TryPlaceNearExisting(grid, word);
        }

        private bool TryPlaceNearExisting(CrosswordGrid grid, string word)
        {
            int attempts = 0;

            while (attempts < MAX_ATTEMPTS)
            {
                // Выбираем случайное направление
                var direction = _random.Next(2) == 0 ? Direction.Horizontal : Direction.Vertical;

                // Выбираем случайные координаты
                int x, y;

                if (direction == Direction.Horizontal)
                {
                    x = _random.Next(grid.Size - word.Length + 1);
                    y = _random.Next(grid.Size);
                }
                else // Vertical
                {
                    x = _random.Next(grid.Size);
                    y = _random.Next(grid.Size - word.Length + 1);
                }

                if (grid.CanPlace(word, x, y, direction))
                {
                    grid.Place(word, x, y, direction);
                    return true;
                }

                attempts++;
            }

            return false;
        }
    }

    // CrosswordGame.cs (для ученика)
    public class CrosswordGame
    {
        private readonly CrosswordGrid _cw;
        private readonly HashSet<string> _solved = new HashSet<string>();
        private List<CrosswordQuestion> _questions;

        public CrosswordGame(CrosswordGrid cw, List<CrosswordQuestion> questions)
        {
            _cw = cw;
            _questions = questions;
        }

        public bool TrySolve(int questionIndex, string userAnswer)
        {
            if (questionIndex < 0 || questionIndex >= _questions.Count)
                return false;

            var question = _questions[questionIndex];

            if (string.Equals(question.Answer, userAnswer, StringComparison.OrdinalIgnoreCase))
            {
                question.Solved = true;
                _solved.Add(question.Answer);
                return true;
            }

            return false;
        }

        public char? GetCell(int x, int y)
        {
            // Проверяем все решенные слова
            foreach (var placement in _cw.Placements)
            {
                if (_solved.Contains(placement.Word))
                {
                    for (int i = 0; i < placement.Word.Length; i++)
                    {
                        int cx = placement.X + (placement.Direction == Direction.Horizontal ? i : 0);
                        int cy = placement.Y + (placement.Direction == Direction.Vertical ? i : 0);

                        if (cx == x && cy == y)
                        {
                            return placement.Word[i];
                        }
                    }
                }
            }

            return null;
        }

        public CrosswordGrid Crossword => _cw;
        public List<CrosswordQuestion> Questions => _questions;
        public int SolvedCount => _solved.Count;
        public int TotalQuestions => _questions?.Count ?? 0;
        public bool IsComplete => SolvedCount == TotalQuestions;

        public void MarkAsSolved(string word)
        {
            _solved.Add(word.ToUpper());
        }

        public bool IsWordSolved(string word)
        {
            return _solved.Contains(word.ToUpper());
        }

        // Новый метод для получения размещения по индексу вопроса
        public WordPlacement GetPlacementForQuestion(int questionNumber)
        {
            if (questionNumber <= 0 || questionNumber > _cw.Placements.Count)
                return null;

            // ВАЖНО: предполагаем, что размещения идут в том же порядке, что и вопросы
            return _cw.Placements[questionNumber - 1];
        }
    }

    // CrosswordQuestion.cs (вместо QuestionItem)
    public class CrosswordQuestion
    {
        public string Question { get; set; } = string.Empty;
        public string Answer { get; set; } = string.Empty;
        public bool Solved { get; set; }
        public int Number { get; set; }
    }

    // SimpleCrosswordGenerator.cs - для простого размещения слов в ряд
    public class SimpleCrosswordGenerator
    {
        public CrosswordGrid GenerateSimple(string[] words, int size = 15)
        {
            var grid = new CrosswordGrid(size);

            if (words == null || words.Length == 0)
                return grid;

            // Фильтруем и приводим к верхнему регистру
            var validWords = words
                .Where(w => !string.IsNullOrEmpty(w))
                .Select(w => w.ToUpper())
                .ToList();

            if (!validWords.Any())
                return grid;

            // Просто размещаем слова одно под другим
            int currentY = 1;

            foreach (var word in validWords)
            {
                if (currentY >= size - 1) break; // Не выходим за пределы сетки

                // Вычисляем координату X для центрирования
                int x = (size - word.Length) / 2;

                // Проверяем, помещается ли слово
                if (x < 0) x = 0;
                if (x + word.Length > size) continue;

                // Проверяем, можно ли разместить
                bool canPlace = true;
                for (int i = 0; i < word.Length; i++)
                {
                    if (grid.Grid[x + i, currentY] != null)
                    {
                        canPlace = false;
                        break;
                    }
                }

                if (canPlace)
                {
                    grid.Place(word, x, currentY, Direction.Horizontal);
                    currentY += 2; // Пропускаем строку между словами
                }
                else
                {
                    // Пробуем следующую строку
                    currentY++;
                }
            }

            return grid;
        }
    }
}