﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OurProj
{
    public class CrosswordResult
    {
        public string StudentName { get; set; }
        public string StudentGroup { get; set; }
        public int TotalWords { get; set; }
        public int SolvedWords { get; set; }
        public double Percentage { get; set; }
        public DateTime CompletionTime { get; set; }
        public TimeSpan TimeSpent { get; set; }
        public List<CrosswordWordResult> WordResults { get; set; } = new List<CrosswordWordResult>();
    }

    public class CrosswordWordResult
    {
        public int QuestionNumber { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        public bool Solved { get; set; }
    }
}