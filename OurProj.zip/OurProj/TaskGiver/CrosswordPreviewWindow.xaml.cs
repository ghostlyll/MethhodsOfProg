﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Windows.Controls.Primitives;

namespace TaskGiver
{
    public partial class CrosswordPreviewWindow : Window
    {
        public class CellViewModel
        {
            public string Letter { get; set; }
            public Brush Background { get; set; }
        }

        public class QuestionViewModel
        {
            public int Number { get; set; }
            public string Question { get; set; }
            public string Answer { get; set; }
        }

        public CrosswordPreviewWindow(OurProj.CrosswordGameWrapper crosswordWrapper)
        {
            InitializeComponent();
            LoadCrosswordPreview(crosswordWrapper);
        }

        private void LoadCrosswordPreview(OurProj.CrosswordGameWrapper crosswordWrapper)
        {
            var grid = crosswordWrapper.Grid;

            // Устанавливаем информацию о кроссворде
            CrosswordInfoText.Text = $"Слов: {crosswordWrapper.Questions.Count} | " +
                                    $"Размер: {grid.Size}x{grid.Size} | " +
                                    $"Создан: {DateTime.Now:dd.MM.yyyy HH:mm}";

            // Простой способ: создаем UniformGrid в коде
            UniformGrid uniformGrid = new UniformGrid();
            uniformGrid.Columns = grid.Size;
            uniformGrid.Rows = grid.Size;

            // Заменяем ItemsPanel
            ItemsPanelTemplate template = new ItemsPanelTemplate();
            FrameworkElementFactory factory = new FrameworkElementFactory(typeof(UniformGrid));
            factory.SetValue(UniformGrid.ColumnsProperty, grid.Size);
            factory.SetValue(UniformGrid.RowsProperty, grid.Size);
            template.VisualTree = factory;

            CrosswordGrid.ItemsPanel = template;

            // Создаем ViewModel для ячеек
            var cellViewModels = new ObservableCollection<CellViewModel>();

            for (int y = 0; y < grid.Size; y++)
            {
                for (int x = 0; x < grid.Size; x++)
                {
                    var cell = grid.Grid[x, y];
                    cellViewModels.Add(new CellViewModel
                    {
                        Letter = cell?.ToString() ?? "",
                        Background = cell == null ? Brushes.Black : Brushes.White
                    });
                }
            }

            CrosswordGrid.ItemsSource = cellViewModels;

            // Создаем ViewModel для вопросов
            var questionViewModels = new ObservableCollection<QuestionViewModel>();
            foreach (var question in crosswordWrapper.Questions)
            {
                questionViewModels.Add(new QuestionViewModel
                {
                    Number = question.Number,
                    Question = question.Question,
                    Answer = question.Answer
                });
            }

            QuestionsList.ItemsSource = questionViewModels;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}