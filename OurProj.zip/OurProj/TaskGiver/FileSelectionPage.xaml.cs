﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Xml.Linq;

namespace TaskGiver
{
    public partial class FileSelectionPage : Page
    {
        private string _userRole;

        public FileSelectionPage(string role)
        {
            InitializeComponent();
            _userRole = role;
            UpdateUI();
        }

        private void UpdateUI()
        {
            if (_userRole == "teacher")
            {
                TitleText.Text = "Учитель: создание игры из TXT файла";
                this.Background = Brushes.LightCoral;
                SelectedFileText.Text = "Выберите TXT файл с вопросами";
            }
            else
            {
                TitleText.Text = "Ученик: прохождение игры";
                this.Background = Brushes.LightGreen;
                SelectedFileText.Text = "Выберите XML файл игры";
            }
        }

        private void SelectFileButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog();

            if (_userRole == "teacher")
            {
                openFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
                openFileDialog.Title = "Выберите текстовый файл с заданиями для учителя";
            }
            else
            {
                openFileDialog.Filter = "XML файлы (*.xml)|*.xml|Все файлы (*.*)|*.*";
                openFileDialog.Title = "Выберите XML файл игры для ученика";
            }

            if (openFileDialog.ShowDialog() == true)
            {
                string selectedFilePath = openFileDialog.FileName;
                string fileName = System.IO.Path.GetFileName(selectedFilePath);
                SelectedFileText.Text = $"Выбран файл: {fileName}";

                // Обрабатываем выбранный файл
                ProcessSelectedFile(selectedFilePath);
            }
        }

        private void ProcessSelectedFile(string filePath)
        {
            try
            {
                if (_userRole == "teacher")
                {
                    // Для учителя: спрашиваем тип игры
                    var gameTypeDialog = new GameTypeDialog();
                    if (gameTypeDialog.ShowDialog() == true)
                    {
                        if (gameTypeDialog.SelectedGameType == "Викторина")
                        {
                            // Создаем викторину из TXT
                            ConvertTxtToQuizXml(filePath);
                        }
                        else if (gameTypeDialog.SelectedGameType == "Кроссворд")
                        {
                            // Создаем кроссворд из TXT
                            ConvertTxtToCrosswordXml(filePath);
                        }
                    }
                }
                else
                {
                    // Для ученика: определяем тип игры по содержимому XML
                    DetermineGameTypeAndStart(filePath);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обработке файла: {ex.Message}",
                               "Ошибка",
                               MessageBoxButton.OK,
                               MessageBoxImage.Error);
            }
        }

        private void ConvertTxtToQuizXml(string txtFilePath)
        {
            try
            {
                // Читаем TXT файл с помощью TaskReader
                var taskReader = new OurProj.TaskReader();
                taskReader.ReadFromFile(txtFilePath);

                if (taskReader.Tasks == null || taskReader.Tasks.Count == 0)
                {
                    MessageBox.Show("Не удалось загрузить задания из файла. Проверьте формат файла.",
                                   "Ошибка",
                                   MessageBoxButton.OK,
                                   MessageBoxImage.Error);
                    return;
                }

                // Проверяем, что у каждого вопроса есть хотя бы один неверный ответ
                var invalidQuestions = new List<int>();
                for (int i = 0; i < taskReader.Tasks.Count; i++)
                {
                    var task = taskReader.Tasks[i];
                    if (task.WrongAnswers == null || task.WrongAnswers.Count == 0)
                    {
                        invalidQuestions.Add(i + 1);
                    }
                }

                if (invalidQuestions.Count > 0)
                {
                    throw new Exception(
                        "Для создания викторины каждый вопрос должен иметь хотя бы один неверный ответ.\n\n" +
                        $"Вопросы без неверных ответов: {string.Join(", ", invalidQuestions)}\n\n" +
                        "Пример правильного формата:\n" +
                        "ЗАДАНИЕ №1\n" +
                        "Какого цвета небо?\n" +
                        "Ответ: Синего\n" +
                        "Неверные ответы: Зелёного, Красного, Желтого");
                }

                // Создаем XML документ
                var xmlDoc = new XDocument(
                    new XElement("quiz",
                        new XElement("info",
                            new XElement("title", "Викторина из TXT файла"),
                            new XElement("sourceFile", System.IO.Path.GetFileName(txtFilePath)),
                            new XElement("creationDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")),
                            new XElement("totalQuestions", taskReader.Tasks.Count)
                        ),
                        taskReader.Tasks.Select(task =>
                            new XElement("question",
                                new XElement("text", task.Question),
                                new XElement("points", "1"),
                                new XElement("answers",
                                    // Правильный ответ
                                    new XElement("answer",
                                        new XAttribute("correct", "true"),
                                        task.Answer
                                    ),
                                    // Неправильные ответы
                                    task.WrongAnswers.Select(wrongAnswer =>
                                        new XElement("answer",
                                            new XAttribute("correct", "false"),
                                            wrongAnswer
                                        )
                                    )
                                )
                            )
                        )
                    )
                );

                // Предлагаем сохранить XML файл
                var saveDialog = new SaveFileDialog();
                saveDialog.Filter = "XML файлы (*.xml)|*.xml|Все файлы (*.*)|*.*";
                saveDialog.Title = "Сохранить викторину как XML";
                saveDialog.FileName = $"quiz_{DateTime.Now:yyyyMMdd_HHmmss}.xml";
                saveDialog.DefaultExt = ".xml";

                if (saveDialog.ShowDialog() == true)
                {
                    xmlDoc.Save(saveDialog.FileName);

                    MessageBox.Show($"Викторина успешно создана!\n\n" +
                                   $"Загружено заданий: {taskReader.Tasks.Count}\n" +
                                   $"Сохранено в файл: {System.IO.Path.GetFileName(saveDialog.FileName)}\n\n" +
                                   $"Теперь этот XML файл можно использовать для проведения викторины.",
                                   "Успех",
                                   MessageBoxButton.OK,
                                   MessageBoxImage.Information);

                    // Показываем предпросмотр созданной викторины
                    ShowQuizPreview(taskReader);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании XML: {ex.Message}",
                               "Ошибка",
                               MessageBoxButton.OK,
                               MessageBoxImage.Error);
            }
        }

        private void ConvertTxtToCrosswordXml(string txtFilePath)
        {
            try
            {
                // Создаем кроссворд из TXT
                var crosswordWrapper = new OurProj.CrosswordGameWrapper();
                crosswordWrapper.CreateFromTxt(txtFilePath);

                if (!crosswordWrapper.IsPossibleToConstruct())
                {
                    MessageBox.Show("Не удалось создать кроссворд из файла.",
                                   "Ошибка",
                                   MessageBoxButton.OK,
                                   MessageBoxImage.Error);
                    return;
                }

                // Предлагаем сохранить XML файл
                var saveDialog = new SaveFileDialog();
                saveDialog.Filter = "XML файлы (*.xml)|*.xml|Все файлы (*.*)|*.*";
                saveDialog.Title = "Сохранить кроссворд как XML";
                saveDialog.FileName = $"crossword_{DateTime.Now:yyyyMMdd_HHmmss}.xml";
                saveDialog.DefaultExt = ".xml";

                if (saveDialog.ShowDialog() == true)
                {
                    // Сохраняем кроссворд в XML
                    crosswordWrapper.SaveCrosswordAsXML(saveDialog.FileName);

                    MessageBox.Show($"Кроссворд успешно создан!\n\n" +
                                   $"Количество слов: {crosswordWrapper.Questions.Count}\n" +
                                   $"Размер сетки: {crosswordWrapper.Grid.Size}x{crosswordWrapper.Grid.Size}\n" +
                                   $"Сохранено в файл: {System.IO.Path.GetFileName(saveDialog.FileName)}\n\n" +
                                   $"Теперь этот XML файл можно использовать для игры в кроссворд.",
                                   "Успех",
                                   MessageBoxButton.OK,
                                   MessageBoxImage.Information);

                    // Показываем предпросмотр созданного кроссворда
                    ShowCrosswordPreview(crosswordWrapper);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании кроссворда: {ex.Message}",
                               "Ошибка",
                               MessageBoxButton.OK,
                               MessageBoxImage.Error);
            }
        }

        private void DetermineGameTypeAndStart(string xmlFilePath)
        {
            try
            {
                // Определяем тип игры по содержимому XML
                var xmlDoc = XDocument.Load(xmlFilePath);
                var root = xmlDoc.Root.Name.LocalName;

                if (root == "quiz")
                {
                    // Это викторина
                    StartQuizFromXml(xmlFilePath);
                }
                else if (root == "crossword")
                {
                    // Это кроссворд
                    StartCrosswordFromXml(xmlFilePath);
                }
                else
                {
                    MessageBox.Show("Неизвестный формат XML файла.",
                                   "Ошибка",
                                   MessageBoxButton.OK,
                                   MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при определении типа игры: {ex.Message}",
                               "Ошибка",
                               MessageBoxButton.OK,
                               MessageBoxImage.Error);
            }
        }

        private void StartQuizFromXml(string xmlFilePath)
        {
            try
            {
                // Создаем и загружаем викторину
                var victorine = new OurProj.Victorine();
                victorine.LoadFromXML(xmlFilePath);

                if (!victorine.IsPossibleToConstruct())
                {
                    MessageBox.Show("Не удалось загрузить викторину из файла.",
                                   "Ошибка",
                                   MessageBoxButton.OK,
                                   MessageBoxImage.Error);
                    return;
                }

                // Переходим на страницу регистрации
                NavigationService.Navigate(new StudentRegistrationPage(victorine));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке викторины: {ex.Message}",
                               "Ошибка",
                               MessageBoxButton.OK,
                               MessageBoxImage.Error);
            }
        }

        private void StartCrosswordFromXml(string xmlFilePath)
        {
            try
            {
                // Создаем и загружаем кроссворд
                var crosswordWrapper = new OurProj.CrosswordGameWrapper();
                crosswordWrapper.LoadForStudent(xmlFilePath); // Используем новый метод

                if (!crosswordWrapper.IsPossibleToConstruct())
                {
                    MessageBox.Show("Не удалось загрузить кроссворд из файла.",
                                   "Ошибка",
                                   MessageBoxButton.OK,
                                   MessageBoxImage.Error);
                    return;
                }

                // Переходим на страницу регистрации
                NavigationService.Navigate(new StudentRegistrationPage(crosswordWrapper));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке кроссворда: {ex.Message}",
                               "Ошибка",
                               MessageBoxButton.OK,
                               MessageBoxImage.Error);
            }
        }

       
        private void ShowQuizPreview(OurProj.TaskReader taskReader)
        {
            var previewWindow = new QuizPreviewWindow(taskReader);
            previewWindow.Owner = Window.GetWindow(this);
            previewWindow.ShowDialog();
        }

        private void ShowCrosswordPreview(OurProj.CrosswordGameWrapper crosswordWrapper)
        {
            var previewWindow = new CrosswordPreviewWindow(crosswordWrapper);
            previewWindow.Owner = Window.GetWindow(this);
            previewWindow.ShowDialog();
        }

        private bool ValidateTxtFile(string filePath, out string errorMessage)
        {
            errorMessage = string.Empty;

            try
            {
                var taskReader = new OurProj.TaskReader();
                taskReader.ReadFromFile(filePath);

                if (taskReader.Tasks.Count == 0)
                {
                    errorMessage = "Файл не содержит корректных заданий.";
                    return false;
                }

                // Проверяем каждый вопрос
                var errors = new List<string>();
                for (int i = 0; i < taskReader.Tasks.Count; i++)
                {
                    var task = taskReader.Tasks[i];

                    if (string.IsNullOrEmpty(task.Question))
                    {
                        errors.Add($"Вопрос №{task.Number}: отсутствует текст вопроса");
                    }

                    if (string.IsNullOrEmpty(task.Answer))
                    {
                        errors.Add($"Вопрос №{task.Number}: отсутствует правильный ответ");
                    }

                    if (task.WrongAnswers == null || task.WrongAnswers.Count == 0)
                    {
                        errors.Add($"Вопрос №{task.Number}: отсутствуют неверные ответы");
                    }
                }

                if (errors.Count > 0)
                {
                    errorMessage = "Обнаружены ошибки в формате:\n\n" +
                                  string.Join("\n", errors) +
                                  "\n\nКаждый вопрос должен иметь:\n" +
                                  "1. Текст вопроса\n" +
                                  "2. Правильный ответ (Ответ: ...)\n" +
                                  "3. Хотя бы один неверный ответ (Неверные ответы: ...)";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = $"Ошибка при проверке файла: {ex.Message}";
                return false;
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }
    }
}