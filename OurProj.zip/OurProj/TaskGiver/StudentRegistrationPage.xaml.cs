﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TaskGiver
{
    public partial class StudentRegistrationPage : Page
    {
        private object _game;
        private string _gameType;

        // Конструктор для викторины
        public StudentRegistrationPage(OurProj.Victorine victorine)
        {
            InitializeComponent();
            _game = victorine;
            _gameType = "quiz";
            UpdateUI();
        }

        // Конструктор для кроссворда
        public StudentRegistrationPage(OurProj.CrosswordGameWrapper crosswordWrapper)
        {
            InitializeComponent();
            _game = crosswordWrapper;
            _gameType = "crossword";
            UpdateUI();
        }

        // Конструктор по умолчанию (для дизайнера)
        public StudentRegistrationPage()
        {
            InitializeComponent();
            _gameType = "quiz"; // Значение по умолчанию
        }

        private void UpdateUI()
        {
            if (_gameType == "crossword")
            {
                Title = "Регистрация для кроссворда";
                // Можно изменить другие элементы UI
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
                NavigationService.GoBack();
        }

        private void StartQuizButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FirstNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(LastNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(GroupTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все поля!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (_gameType == "quiz" && _game is OurProj.Victorine victorine)
            {
                // Для викторины
                victorine.SetStudent(
                    FirstNameTextBox.Text.Trim(),
                    LastNameTextBox.Text.Trim(),
                    GroupTextBox.Text.Trim()
                );

                victorine.PlayGame();
                NavigationService.Navigate(new QuizPage(victorine));
            }
            else if (_gameType == "crossword" && _game is OurProj.CrosswordGameWrapper crosswordWrapper)
            {
                // Для кроссворда
                crosswordWrapper.SetStudent(
                    FirstNameTextBox.Text.Trim(),
                    LastNameTextBox.Text.Trim(),
                    GroupTextBox.Text.Trim()
                );

                crosswordWrapper.PlayGame();
                NavigationService.Navigate(new CrosswordPage(crosswordWrapper));
            }
            else
            {
                MessageBox.Show("Ошибка: неизвестный тип игры", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}