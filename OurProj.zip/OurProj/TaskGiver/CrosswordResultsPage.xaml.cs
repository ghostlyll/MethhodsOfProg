﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using System.Collections.ObjectModel;

namespace TaskGiver
{
    public partial class CrosswordResultsPage : Page
    {
        private OurProj.CrosswordGameWrapper _crosswordWrapper;

        public class SolvedWordViewModel
        {
            public string Question { get; set; }
            public string Answer { get; set; }
        }

        public CrosswordResultsPage(OurProj.CrosswordGameWrapper crosswordWrapper)
        {
            InitializeComponent();
            _crosswordWrapper = crosswordWrapper;
            LoadResults();
        }

        private void LoadResults()
        {
            var result = _crosswordWrapper.CurrentResult;

            if (result == null)
            {
                // Создаем тестовые данные для отладки
                result = new OurProj.CrosswordResult
                {
                    StudentName = "Тест Тестов",
                    StudentGroup = "Группа 101",
                    TotalWords = 5,
                    SolvedWords = 3,
                    Percentage = 60.0,
                    CompletionTime = DateTime.Now,
                    TimeSpent = TimeSpan.FromMinutes(5)
                };
            }

            // Отображаем информацию о студенте
            StudentInfoText.Text = $"{result.StudentName}, группа {result.StudentGroup}";

            // Отображаем время
            TimeText.Text = result.TimeSpent.ToString(@"mm\:ss");
            DateText.Text = result.CompletionTime.ToString("dd.MM.yyyy HH:mm");

            // Отображаем результаты
            SolvedWordsText.Text = result.SolvedWords.ToString();
            TotalWordsText.Text = result.TotalWords.ToString();
            PercentageText.Text = $"{result.Percentage:F1}%";

            // Анимация прогресс-бара
            double progressWidth = Math.Min(result.Percentage * 4, 400);
            ProgressIndicator.BeginAnimation(Border.WidthProperty,
                new DoubleAnimation(0, progressWidth, TimeSpan.FromSeconds(1.5)));

            // Отображаем сообщение в зависимости от результата
            string message;
            if (result.Percentage >= 90)
                message = "Отличный результат! Вы прекрасно справились с кроссвордом! 🎉";
            else if (result.Percentage >= 70)
                message = "Хороший результат! Вы хорошо знаете материал! 👍";
            else if (result.Percentage >= 50)
                message = "Удовлетворительный результат. Есть над чем поработать! 🤔";
            else
                message = "Попробуйте еще раз! Рекомендуется повторить материал. 📚";

            ResultMessageText.Text = message;

            // Загружаем разгаданные слова
            var solvedWords = new ObservableCollection<SolvedWordViewModel>();

            if (result.WordResults != null && result.WordResults.Any())
            {
                foreach (var word in result.WordResults.OrderBy(w => w.QuestionNumber))
                {
                    solvedWords.Add(new SolvedWordViewModel
                    {
                        Question = $"{word.QuestionNumber}. {word.Question}",
                        Answer = word.Answer
                    });
                }
            }
            //else
            //{
            //    // Тестовые данные для отладки
            //    solvedWords.Add(new SolvedWordViewModel
            //    {
            //        Question = "1. Когда распался СССР?",
            //        Answer = "СССР"
            //    });
            //    solvedWords.Add(new SolvedWordViewModel
            //    {
            //        Question = "2. Где брать комплектующие для компьютера?",
            //        Answer = "ДНС"
            //    });
            //    solvedWords.Add(new SolvedWordViewModel
            //    {
            //        Question = "3. Столица Франции?",
            //        Answer = "ПАРИЖ"
            //    });
            //}

            //SolvedWordsList.ItemsSource = solvedWords;
        }

        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Возвращаемся на главную страницу выбора роли
            NavigationService.Navigate(new RoleSelectionPage());
        }
        
    }
}