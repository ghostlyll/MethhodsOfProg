﻿using OurProj;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TaskGiver
{
    public partial class CrosswordPage : Page
    {
        private OurProj.CrosswordGameWrapper _crosswordWrapper;
        private ObservableCollection<CrosswordQuestionViewModel> _questionViewModels;
        private ObservableCollection<CrosswordCellViewModel> _cellViewModels;

        public class CrosswordCellViewModel : INotifyPropertyChanged
        {
            private string _displayLetter = "";
            private int _number;
            private Brush _background;
            private Brush _foreground;

            public string DisplayLetter
            {
                get => _displayLetter;
                set
                {
                    if (_displayLetter != value)
                    {
                        _displayLetter = value;
                        OnPropertyChanged(nameof(DisplayLetter));
                    }
                }
            }

            public int Number
            {
                get => _number;
                set
                {
                    if (_number != value)
                    {
                        _number = value;
                        OnPropertyChanged(nameof(Number));
                        OnPropertyChanged(nameof(NumberVisibility));
                    }
                }
            }

            public Brush Background
            {
                get => _background;
                set
                {
                    if (_background != value)
                    {
                        _background = value;
                        OnPropertyChanged(nameof(Background));
                    }
                }
            }

            public Brush Foreground
            {
                get => _foreground;
                set
                {
                    if (_foreground != value)
                    {
                        _foreground = value;
                        OnPropertyChanged(nameof(Foreground));
                    }
                }
            }

            public string OriginalLetter { get; set; } = "";
            public bool IsRevealed { get; set; } = false;
            public Visibility NumberVisibility => Number > 0 ? Visibility.Visible : Visibility.Collapsed;

            public event PropertyChangedEventHandler PropertyChanged;
            protected virtual void OnPropertyChanged(string propertyName)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public class CrosswordQuestionViewModel : INotifyPropertyChanged
        {
            private int _number;
            private string _question;
            private string _answer;
            private string _userAnswer;
            private bool _solved;

            public int Number
            {
                get => _number;
                set
                {
                    _number = value;
                    OnPropertyChanged(nameof(Number));
                }
            }

            public string Question
            {
                get => _question;
                set
                {
                    _question = value;
                    OnPropertyChanged(nameof(Question));
                }
            }

            public string Answer
            {
                get => _answer;
                set
                {
                    _answer = value;
                    OnPropertyChanged(nameof(Answer));
                }
            }

            public string UserAnswer
            {
                get => _userAnswer;
                set
                {
                    _userAnswer = value;
                    OnPropertyChanged(nameof(UserAnswer));
                }
            }

            public bool Solved
            {
                get => _solved;
                set
                {
                    _solved = value;
                    OnPropertyChanged(nameof(Solved));
                    OnPropertyChanged(nameof(StatusText));
                    OnPropertyChanged(nameof(StatusColor));
                    OnPropertyChanged(nameof(QuestionBackground));
                    OnPropertyChanged(nameof(IsEnabled));
                }
            }

            public bool IsEnabled => !_solved;
            public string StatusText => Solved ? "✓ Решено" : "Не решено";
            public Brush StatusColor => Solved ? Brushes.Green : Brushes.Gray;
            public Brush QuestionBackground => Solved ? Brushes.LightGreen : Brushes.Transparent;

            public event PropertyChangedEventHandler PropertyChanged;
            protected virtual void OnPropertyChanged(string propertyName)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public CrosswordPage(OurProj.CrosswordGameWrapper crosswordWrapper)
        {
            try
            {
                InitializeComponent();
                _crosswordWrapper = crosswordWrapper;
                InitializeGame();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании страницы кроссворда: {ex.Message}",
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InitializeGame()
        {
            try
            {
                var grid = _crosswordWrapper?.Grid;
                var questions = _crosswordWrapper?.Questions;

                if (grid == null)
                {
                    MessageBox.Show("Сетка кроссворда не загружена", "Ошибка");
                    return;
                }

                // Инициализируем сетку
                InitializeGrid(grid);

                // Создаем ViewModel для вопросов
                _questionViewModels = new ObservableCollection<CrosswordQuestionViewModel>();
                if (questions != null)
                {
                    foreach (var question in questions)
                    {
                        _questionViewModels.Add(new CrosswordQuestionViewModel
                        {
                            Number = question.Number,
                            Question = question.Question,
                            Answer = question.Answer,
                            Solved = question.Solved,
                            UserAnswer = ""
                        });
                    }

                    QuestionsList.ItemsSource = _questionViewModels;
                }

                UpdateProgress();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка инициализации игры: {ex.Message}",
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InitializeGrid(OurProj.CrosswordGrid grid)
        {
            try
            {
                _cellViewModels = new ObservableCollection<CrosswordCellViewModel>();

                // Сначала создаем все ячейки
                for (int y = 0; y < grid.Size; y++)
                {
                    for (int x = 0; x < grid.Size; x++)
                    {
                        var cell = grid.Grid[x, y];
                        bool isBlack = cell == null;

                        var cellViewModel = new CrosswordCellViewModel
                        {
                            DisplayLetter = "", // Пусто изначально
                            Number = 0,
                            Background = isBlack ? Brushes.Black : Brushes.White,
                            Foreground = isBlack ? Brushes.Transparent : Brushes.Black,
                            OriginalLetter = cell?.ToString() ?? ""
                        };

                        _cellViewModels.Add(cellViewModel);
                    }
                }

                // Проставляем номера для начала слов
                if (grid.Placements != null)
                {
                    int wordNumber = 1;
                    foreach (var placement in grid.Placements)
                    {
                        int index = placement.Y * grid.Size + placement.X;
                        if (index < _cellViewModels.Count)
                        {
                            _cellViewModels[index].Number = wordNumber;
                        }
                        wordNumber++;
                    }
                }

                // Устанавливаем источник данных для сетки
                CrosswordGrid.ItemsSource = _cellViewModels;

                // Настраиваем UniformGrid
                var uniformGrid = new UniformGrid();
                uniformGrid.Columns = grid.Size;
                uniformGrid.Rows = grid.Size;

                var template = new ItemsPanelTemplate();
                var factory = new FrameworkElementFactory(typeof(UniformGrid));
                factory.SetValue(UniformGrid.ColumnsProperty, grid.Size);
                factory.SetValue(UniformGrid.RowsProperty, grid.Size);
                template.VisualTree = factory;
                CrosswordGrid.ItemsPanel = template;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка инициализации сетки: {ex.Message}", "Ошибка");
            }
        }

        private void UpdateProgress()
        {
            try
            {
                int solved = _questionViewModels?.Count(q => q.Solved) ?? 0;
                int total = _questionViewModels?.Count ?? 0;
                ProgressText.Text = $"{solved}/{total}";
            }
            catch
            {
                ProgressText.Text = "0/0";
            }
        }

        private void CheckAnswerButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var button = sender as Button;
                if (button?.Tag is int questionNumber)
                {
                    var questionVM = _questionViewModels.FirstOrDefault(q => q.Number == questionNumber);
                    if (questionVM != null && !string.IsNullOrWhiteSpace(questionVM.UserAnswer))
                    {
                        // Ищем соответствующий вопрос в обертке
                        var question = _crosswordWrapper.Questions
                            .FirstOrDefault(q => q.Number == questionNumber);

                        if (question == null) return;

                        // Проверяем ответ
                        bool isCorrect = string.Equals(
                            questionVM.UserAnswer.Trim(),
                            question.Answer.Trim(),
                            StringComparison.OrdinalIgnoreCase);

                        if (isCorrect)
                        {
                            questionVM.Solved = true;
                            questionVM.Answer = question.Answer; // Устанавливаем правильный ответ
                            question.Solved = true;

                            StatusText.Text = $"Правильно! Слово '{question.Answer}' разгадано.";

                            // Обновляем сетку - показываем буквы разгаданного слова
                            RevealWordInGrid(questionNumber);
                            UpdateProgress();

                            // Сохраняем результат в обертке
                            _crosswordWrapper.CheckAnswer(questionVM.UserAnswer, questionNumber);

                            // Проверяем, все ли слова разгаданы
                            if (_questionViewModels.All(q => q.Solved))
                            {
                                CompleteCrossword();
                            }
                        }
                        else
                        {
                            StatusText.Text = "Неверный ответ. Попробуйте еще раз.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                StatusText.Text = $"Ошибка: {ex.Message}";
            }
        }
        private void RevealWordInGrid(int questionNumber)
        {
            try
            {
                var grid = _crosswordWrapper?.Grid;
                if (grid == null || grid.Placements == null) return;

                // Находим вопрос по номеру
                var question = _crosswordWrapper.Questions
                    .FirstOrDefault(q => q.Number == questionNumber);

                if (question == null) return;

                // Находим размещение для этого вопроса (индекс на 1 меньше, так как Placement[0] соответствует вопросу 1)
                int placementIndex = questionNumber - 1;

                if (placementIndex >= 0 && placementIndex < grid.Placements.Count)
                {
                    var placement = grid.Placements[placementIndex];

                    // Проверяем, что слово в размещении соответствует ответу на вопрос
                    if (!string.Equals(placement.Word, question.Answer, StringComparison.OrdinalIgnoreCase))
                    {
                        // Ищем правильное размещение
                        placement = grid.Placements.FirstOrDefault(p =>
                            string.Equals(p.Word, question.Answer, StringComparison.OrdinalIgnoreCase));

                        if (placement == null) return;
                    }

                    // Показываем каждую букву слова
                    for (int i = 0; i < placement.Word.Length; i++)
                    {
                        int x = placement.X + (placement.Direction == Direction.Horizontal ? i : 0);
                        int y = placement.Y + (placement.Direction == Direction.Vertical ? i : 0);

                        if (x >= 0 && x < grid.Size && y >= 0 && y < grid.Size)
                        {
                            int index = y * grid.Size + x;

                            if (index >= 0 && index < _cellViewModels.Count)
                            {
                                var cellViewModel = _cellViewModels[index];

                                // Отображаем правильную букву
                                cellViewModel.DisplayLetter = placement.Word[i].ToString();
                                cellViewModel.Foreground = Brushes.DarkGreen;
                                cellViewModel.Background = Brushes.LightYellow;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при отображении слова: {ex.Message}");
            }
        }
        private void CompleteCrossword()
        {
            try
            {
                // Сохраняем результаты
                _crosswordWrapper.SaveAnswers();
                _crosswordWrapper.SaveAsXML();

                // Переходим на страницу результатов
                NavigationService.Navigate(new CrosswordResultsPage(_crosswordWrapper));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при завершении: {ex.Message}",
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FinishButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MessageBox.Show("Завершить кроссворд? Незавершенные слова будут отмечены как нерешенные.",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    CompleteCrossword();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MessageBox.Show("Вы уверены, что хотите прервать игру? Все результаты будут потеряны.",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    NavigationService.GoBack();
                }
            }
            catch
            {
                NavigationService.GoBack();
            }
        }
    }
}